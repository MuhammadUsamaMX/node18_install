<?php

require_once __DIR__ . '/prod_h595e1f6e22e2a86f634361c6b7a290b2/Shopware_Core_KernelProdContainer.preload.php';